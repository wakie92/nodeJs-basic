var express = require('express')
var router = express.Router();
const Board = require('./model/boardModel');

//list조회
router.get('/', function(req, res, next){
    Board.findAll({
            attributes: ['no','title', 'reg_date', 'view_cnt']
    }).then(data =>{
        console.log(data);
        res.render('board/list.jade', {
            boards : data
        })
        /* for(var board of data) {
            console.log(board);
            res.render('board/list.jade', {
                boards : board
            })
        } */
    })
    .catch(err =>{
        console.log(err);
    })
})
router.get('/post', function(req,res,nex){

    res.render('board/write.jade')
})

module.exports = router;
