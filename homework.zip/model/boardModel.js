const sequelize = require('./sequelize');
const Sequelize = require('sequelize');

const Board = sequelize.define('boards', {
    id : {
        type : Sequelize.UUID,
        defaultValue : Sequelize.UUIDV4,
        primaryKey : true
    },
    no : {
        type : Sequelize.INTEGER
    },
    content : {
        type : Sequelize.TEXT
    },
    title : {
        type : Sequelize.STRING
    },
    reg_date : {
        type : Sequelize.DATEONLY,
        defaultValue : Sequelize.NOW
    },
    view_cnt : {
        type : Sequelize.INTEGER
    }
},
    {
        timestamps : false
    }
)

Board.sync()
    .then(()=> {
        console.log('***** Board sync *****')
    })
    .catch(()=>{
        console.log('***** Board sync *****')
    })
module.exports = Board;